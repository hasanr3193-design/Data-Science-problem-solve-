"""CodeAlpha Task 3: Car Price Prediction with Machine Learning"""
import pandas as pd, numpy as np, matplotlib, joblib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.compose import TransformedTargetRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

df = pd.read_csv("data/car data.csv")
print(df.shape, df.isnull().sum().sum(), "missing;", df.duplicated().sum(), "duplicates")
df = df.drop_duplicates()
df = df[df.Driven_kms < 200000]   # remove extreme outlier (500,000 km) that distorts linear models

# Feature engineering
df["Car_Age"] = df.Year.max() + 1 - df.Year
df["Brand"] = df.Car_Name.str.split().str[0].str.lower()   # brand goodwill proxy
brand_counts = df.Brand.value_counts()
df["Brand"] = df.Brand.where(df.Brand.map(brand_counts) >= 3, "other")
df["Log_Kms"] = np.log1p(df.Driven_kms)
df["Log_Present_Price"] = np.log1p(df.Present_Price)   # log-log keeps linear models stable on luxury outliers

X = df[["Log_Present_Price","Log_Kms","Car_Age","Owner","Fuel_Type","Selling_type","Transmission","Brand"]]
y = df.Selling_Price
num = ["Log_Present_Price","Log_Kms","Car_Age","Owner"]; cat = ["Fuel_Type","Selling_type","Transmission","Brand"]
pre = ColumnTransformer([("n", StandardScaler(), num), ("c", OneHotEncoder(handle_unknown="ignore"), cat)])

Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42)
models = {"Linear Regression": LinearRegression(), "Ridge": Ridge(1.0),
          "Random Forest": RandomForestRegressor(300, random_state=42),
          "Gradient Boosting": GradientBoostingRegressor(random_state=42)}
rows, fitted = [], {}
for n, m in models.items():
    p = TransformedTargetRegressor(Pipeline([("pre", pre), ("m", m)]), func=np.log1p, inverse_func=np.expm1)  # log target tames price skew
    cv = cross_val_score(p, Xtr, ytr, cv=5, scoring="r2").mean()
    p.fit(Xtr, ytr); pr = p.predict(Xte); fitted[n] = p
    rows.append([n, cv, r2_score(yte, pr), mean_absolute_error(yte, pr), np.sqrt(mean_squared_error(yte, pr))])
res = pd.DataFrame(rows, columns=["Model","CV_R2","Test_R2","MAE","RMSE"]).set_index("Model")
print(res.round(3)); res.to_csv("outputs/model_comparison.csv")

best = res.CV_R2.idxmax(); print("Best model:", best)
pr = fitted[best].predict(Xte)
plt.figure(figsize=(6,6)); plt.scatter(yte, pr, alpha=.7); lim=[0,max(yte.max(),pr.max())+1]
plt.plot(lim, lim, "r--"); plt.xlabel("Actual (lakhs)"); plt.ylabel("Predicted (lakhs)")
plt.title(f"Actual vs Predicted - {best}"); plt.tight_layout(); plt.savefig("outputs/actual_vs_predicted.png", dpi=120); plt.close()

# Feature importance (tree model)
rf = fitted["Random Forest"].regressor_; names = rf.named_steps["pre"].get_feature_names_out()
imp = pd.Series(rf.named_steps["m"].feature_importances_, index=names).sort_values().tail(10)
imp.plot.barh(figsize=(8,5), title="Top Feature Importances (Random Forest)"); plt.tight_layout()
plt.savefig("outputs/feature_importance.png", dpi=120)
joblib.dump(fitted[best], "outputs/car_price_model.joblib")
