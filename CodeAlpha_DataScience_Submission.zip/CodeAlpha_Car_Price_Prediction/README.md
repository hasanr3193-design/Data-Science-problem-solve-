# CodeAlpha_Car_Price_Prediction
Task 3 – Predict used-car selling price (lakhs).
**Run:** `pip install pandas numpy scikit-learn matplotlib joblib && python car_price_prediction.py`
**Approach:** drop duplicates + extreme outlier → feature engineering (Car_Age, Brand as brand-goodwill proxy, log kms, log present price) → log-transformed target → compare Linear, Ridge, Random Forest, Gradient Boosting.
**Results:** Best = Ridge (CV R² 0.95, test R² ≈ 0.945, MAE ≈ 0.74 lakh). Present price and car age are the strongest drivers.
