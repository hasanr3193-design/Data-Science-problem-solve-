# CodeAlpha Data Science Internship – 4 Tasks
Each folder is a separate GitHub repo (named CodeAlpha_ProjectName) with script, data, outputs and README.
