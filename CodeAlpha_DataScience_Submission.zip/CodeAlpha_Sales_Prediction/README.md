# CodeAlpha_Sales_Prediction
Task 4 – Predict sales from TV / Radio / Newspaper advertising spend.
**Run:** `pip install pandas numpy scikit-learn matplotlib seaborn scipy joblib && python sales_prediction.py`
**Approach:** EDA/correlation → TV×Radio interaction feature → compare Linear, Polynomial, Random Forest, Gradient Boosting → OLS for interpretation.
**Results:** Gradient Boosting test R² ≈ 0.99 (RMSE ≈ 0.52). OLS: TV (+0.046/$1k) and Radio (+0.19/$1k) are significant; Newspaper is not (p=0.86).
**Business insight:** shift budget from newspaper to radio/TV; radio has the highest return per dollar, and TV+Radio together have a synergy effect.
