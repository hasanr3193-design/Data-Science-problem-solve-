"""CodeAlpha Task 4: Sales Prediction using Python"""
import pandas as pd, numpy as np, matplotlib, joblib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

df = pd.read_csv("data/Advertising.csv").iloc[:, 1:]
print(df.shape, df.isnull().sum().sum(), "missing"); print(df.describe())
print(df.corr().round(3))
sns.pairplot(df, kind="reg"); plt.savefig("outputs/pairplot.png", dpi=110); plt.close()
plt.figure(figsize=(5,4)); sns.heatmap(df.corr(), annot=True, cmap="coolwarm"); plt.tight_layout()
plt.savefig("outputs/correlation.png", dpi=120); plt.close()

# Feature engineering: interaction TV x Radio
df["TV_Radio"] = df.TV * df.Radio
X, y = df.drop(columns="Sales"), df.Sales
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42)
models = {"Linear Regression": LinearRegression(),
          "Polynomial (deg 2)": make_pipeline(PolynomialFeatures(2, include_bias=False), LinearRegression()),
          "Random Forest": RandomForestRegressor(300, random_state=42),
          "Gradient Boosting": GradientBoostingRegressor(random_state=42)}
rows, fitted = [], {}
for n, m in models.items():
    cv = cross_val_score(m, Xtr, ytr, cv=5, scoring="r2").mean()
    m.fit(Xtr, ytr); p = m.predict(Xte); fitted[n] = m
    rows.append([n, cv, r2_score(yte,p), mean_absolute_error(yte,p), np.sqrt(mean_squared_error(yte,p))])
res = pd.DataFrame(rows, columns=["Model","CV_R2","Test_R2","MAE","RMSE"]).set_index("Model")
print(res.round(3)); res.to_csv("outputs/model_comparison.csv")
best = res.CV_R2.idxmax(); print("Best:", best)

p = fitted[best].predict(Xte)
plt.figure(figsize=(6,6)); plt.scatter(yte, p, alpha=.7); plt.plot([0,30],[0,30],"r--")
plt.xlabel("Actual Sales"); plt.ylabel("Predicted Sales"); plt.title(f"Actual vs Predicted - {best}")
plt.tight_layout(); plt.savefig("outputs/actual_vs_predicted.png", dpi=120); plt.close()

# Interpretable OLS (numpy/scipy): impact of ad spend on sales
from scipy import stats
A = np.column_stack([np.ones(len(df)), df[["TV","Radio","Newspaper"]].values]); yy = y.values
beta, *_ = np.linalg.lstsq(A, yy, rcond=None)
resid = yy - A @ beta; dof = len(yy) - A.shape[1]; s2 = resid @ resid / dof
se = np.sqrt(np.diag(s2 * np.linalg.inv(A.T @ A))); t = beta / se; pv = 2 * stats.t.sf(abs(t), dof)
ols = pd.DataFrame({"coef": beta, "std_err": se, "t": t, "p_value": pv}, index=["const","TV","Radio","Newspaper"])
ols_r2 = 1 - resid @ resid / ((yy - yy.mean()) @ (yy - yy.mean()))
print(ols.round(4)); print("OLS R2:", round(ols_r2, 4))
ols.to_csv("outputs/ols_summary.csv")
joblib.dump(fitted[best], "outputs/sales_model.joblib")

# Marginal impact: +1 unit (thousand $) per channel
print("\nSales units gained per extra $1k spend:\n", ols.coef[["TV","Radio","Newspaper"]].round(4))
