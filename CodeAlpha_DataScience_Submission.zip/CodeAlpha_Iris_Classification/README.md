# CodeAlpha_Iris_Classification
Task 1 – Iris flower species classification (setosa / versicolor / virginica).
**Run:** `pip install pandas scikit-learn matplotlib seaborn && python iris_classification.py`
**Approach:** EDA (pairplot) → stratified 80/20 split → compare Logistic Regression, KNN, Decision Tree, Random Forest, SVM using 5-fold CV → evaluate best with accuracy, classification report, confusion matrix.
**Results:** All models reach ~90–97% accuracy; best by CV was KNN/SVM (CV 0.967). Setosa is perfectly separable; versicolor/virginica overlap slightly. Petal length/width are the most discriminative features.
