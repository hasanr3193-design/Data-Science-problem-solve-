"""CodeAlpha Task 1: Iris Flower Classification"""
import pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay

df = pd.read_csv("data/Iris.csv").drop(columns="Id")
print(df.shape, df.isnull().sum().sum(), "missing values")
print(df.describe())

sns.pairplot(df, hue="Species"); plt.savefig("outputs/pairplot.png", dpi=120); plt.close()

X, y = df.drop(columns="Species"), df["Species"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

models = {
    "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=500)),
    "KNN": make_pipeline(StandardScaler(), KNeighborsClassifier(5)),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Random Forest": RandomForestClassifier(random_state=42),
    "SVM": make_pipeline(StandardScaler(), SVC()),
}
res = {}
for n, m in models.items():
    cv = cross_val_score(m, Xtr, ytr, cv=5).mean()
    m.fit(Xtr, ytr); acc = accuracy_score(yte, m.predict(Xte))
    res[n] = (cv, acc); print(f"{n:20s} CV={cv:.3f} Test={acc:.3f}")

best = max(res, key=lambda k: res[k][0]); model = models[best]
print("\nBest model (by CV):", best)
pred = model.predict(Xte)
print(classification_report(yte, pred))
ConfusionMatrixDisplay(confusion_matrix(yte, pred), display_labels=model.classes_ if hasattr(model,"classes_") else sorted(y.unique())).plot(cmap="Blues")
plt.title(f"Confusion Matrix - {best}"); plt.tight_layout(); plt.savefig("outputs/confusion_matrix.png", dpi=120)
pd.DataFrame(res, index=["CV accuracy","Test accuracy"]).T.to_csv("outputs/model_comparison.csv")
