"""CodeAlpha Task 2: Unemployment Analysis with Python"""
import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
sns.set_style("whitegrid")

df = pd.read_csv("data/Unemployment in India.csv", encoding="utf-8-sig")
df.columns = df.columns.str.strip()
df = df.dropna(how="all")
df["Region"] = df["Region"].str.strip(); df["Area"] = df["Area"].str.strip()
df["Date"] = pd.to_datetime(df["Date"].str.strip(), format="%d-%m-%Y")
df = df.rename(columns={"Estimated Unemployment Rate (%)":"UnempRate",
                        "Estimated Employed":"Employed",
                        "Estimated Labour Participation Rate (%)":"LPR"})
df["Month"] = df["Date"].dt.month; df["Year"] = df["Date"].dt.year
print(df.shape, "\n", df.isnull().sum(), "\n", df.describe())

# National monthly trend
nat = df.groupby("Date")["UnempRate"].mean()
fig, ax = plt.subplots(figsize=(11,5))
nat.plot(ax=ax, marker="o")
ax.axvspan(pd.Timestamp("2020-03-25"), pd.Timestamp("2020-06-30"), color="red", alpha=.15, label="Covid-19 lockdown")
ax.set_title("Average Unemployment Rate in India (Monthly)"); ax.set_ylabel("%"); ax.legend()
plt.tight_layout(); plt.savefig("outputs/national_trend.png", dpi=120); plt.close()

# Pre vs during Covid
pre = df[df.Date < "2020-03-01"]; covid = df[df.Date >= "2020-04-01"]
print(f"\nPre-Covid mean: {pre.UnempRate.mean():.2f}%  | Apr-Jun 2020 mean: {covid.UnempRate.mean():.2f}%")
peak = nat.idxmax(); print("Peak month:", peak.date(), round(nat.max(),2), "%")

# Rural vs urban
fig, ax = plt.subplots(figsize=(11,5))
sns.lineplot(data=df, x="Date", y="UnempRate", hue="Area", estimator="mean", errorbar=None, marker="o", ax=ax)
ax.set_title("Rural vs Urban Unemployment"); plt.tight_layout(); plt.savefig("outputs/rural_urban.png", dpi=120); plt.close()

# Regional impact (Covid increase)
reg = pd.DataFrame({"pre": pre.groupby("Region").UnempRate.mean(), "covid": covid.groupby("Region").UnempRate.mean()})
reg["increase"] = reg.covid - reg.pre; reg = reg.sort_values("increase", ascending=False)
reg.to_csv("outputs/regional_covid_impact.csv"); print("\nTop 5 hit regions:\n", reg.head())
fig, ax = plt.subplots(figsize=(9,9)); reg["increase"].sort_values().plot.barh(ax=ax, color="tomato")
ax.set_title("Increase in Unemployment Rate: Covid vs Pre-Covid (pp)"); plt.tight_layout()
plt.savefig("outputs/regional_impact.png", dpi=120); plt.close()

# Seasonality (pre-Covid months only, to avoid shock distortion)
seas = df[df.Year == 2019].groupby("Month").UnempRate.mean()
fig, ax = plt.subplots(figsize=(9,4)); seas.plot.bar(ax=ax, color="steelblue")
ax.set_title("Seasonal Pattern - 2019 Avg Unemployment by Month"); plt.tight_layout()
plt.savefig("outputs/seasonality_2019.png", dpi=120); plt.close()

# Heatmap region x month
pv = df.pivot_table(index="Region", columns=df.Date.dt.strftime("%Y-%m"), values="UnempRate")
plt.figure(figsize=(13,9)); sns.heatmap(pv, cmap="YlOrRd"); plt.title("Unemployment Rate Heatmap")
plt.tight_layout(); plt.savefig("outputs/heatmap.png", dpi=120); plt.close()

# Labour participation vs unemployment
plt.figure(figsize=(7,5)); sns.scatterplot(data=df, x="LPR", y="UnempRate", hue="Area", alpha=.6)
plt.title("Labour Participation vs Unemployment"); plt.tight_layout(); plt.savefig("outputs/lpr_vs_unemp.png", dpi=120)
print("\nCorr(LPR, UnempRate):", round(df.LPR.corr(df.UnempRate),3))
