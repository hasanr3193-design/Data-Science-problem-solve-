# CodeAlpha_Unemployment_Analysis
Task 2 – Unemployment in India (May 2019 – Jun 2020), Covid-19 impact.
**Run:** `pip install pandas numpy matplotlib seaborn && python unemployment_analysis.py`
**Approach:** cleaning (strip headers/whitespace, parse dates) → national, rural/urban, regional, seasonal and heatmap visuals.
**Key insights:**
- Average unemployment rose from ~9.5% pre-Covid to ~20.2% in Apr–Jun 2020; peak in May 2020 (~24.9%).
- Hardest hit regions: Puducherry, Jharkhand, Tamil Nadu, Bihar, Karnataka.
- Labour participation is essentially uncorrelated with unemployment rate (r≈0).
- Policy implication: targeted support (rural employment schemes, urban gig/informal worker relief) for high-impact states.
- Note: only ~14 months of data exist, so seasonality is indicative only.
